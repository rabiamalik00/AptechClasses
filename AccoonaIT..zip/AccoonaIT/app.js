let age = 40;
let name = "Rabia";

console.log(age);
console.log(name);

let numString = "10";
let num = Number(numString);

let firstName = "Rabia";
let lastName = "Malik";
let fullName = firstName + " " + lastName;

console.log(fullName);

function greet(){
alert('Welcome to Accoona IT')



}
greet()